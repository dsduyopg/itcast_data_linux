<center><font size=6>MAC电脑vmwre fusion网卡配置</font></center>



# 1. vmware fusion添加网卡新的网卡

<font color=red>**说明：** 默认我们安装完vmware fusion后,默认只有vm1 vm8，做实验增加其他网卡则需要我们手动添加</font>

## 1.1 点击VMwareFusion设置

![image-20251015145703083](images/网卡配置/image-20251015145703083.png)

## 1.2  解锁配置权限

![image-20251015150128346](images/网卡配置/image-20251015150128346.png)

![image-20251015150234065](images/网卡配置/image-20251015150234065.png)



## 1.3 添加网卡

<font color=red>**说明：** 添加网卡的时候 网卡名称自动编号 vmnet2 .... 依次类推，注意 这里面不包含vmnet1 与 vmnet8 安装后默认就有了</font>

![image-20251015150743280](images/网卡配置/image-20251015150743280.png)

<font color=red>**注意：**1. 如果添加host only模式 不要勾选nat选项 2. 设置完我们自己的网卡网段后，请点击应用保存我们的设置 </font>

## 1.4 根据实现要求依次参考上的方式添加更多的网卡



# 2. 单独为虚拟机配置网络适配器

## 2.1 打开设置

![image-20251015151207498](images/网卡配置/image-20251015151207498.png)

## 2.2  为适配器配网络

![image-20251015151348590](images/网卡配置/image-20251015151348590.png)

## 2.3  配置指定网络

![image-20251015152411538](images/网卡配置/image-20251015152411538.png)



# 3. 为虚拟机添加更多的适配器

## 3.1 添加适配器设备

![image-20251015152601836](images/网卡配置/image-20251015152601836.png)

![image-20251015152654950](images/网卡配置/image-20251015152654950.png)

## 3.2 为适配器选择网络 参考上面的教程配置即可

### 3.3  适配器说明

![image-20251015153015234](images/网卡配置/image-20251015153015234.png)



# 4. 默认的VM8网卡配置网段

## 4.1 配置脚本

```shell
#!/bin/bash
# sed usage: https://www.tutorialspoint.com/unix/unix-regular-expressions.html

net_dir='/Library/Preferences/VMware Fusion'
dhcp_dir='/Library/Preferences/VMware Fusion/vmnet8'


echo "back up networking file..."
sudo mv "$net_dir/networking" "$net_dir/networking.bak"

echo "back up dhcpd.conf file..."
sudo mv "$dhcp_dir/dhcpd.conf" "$dhcp_dir/dhcpd.conf.bak"

# recieve subset from use input
echo 'Please input ip subnet address (example: 192.168.88):'
read ip

# sed -i in mac invalid,use >> replace it
# mac sed -i "" 's/pattern/replace/g',"" must exist
# in furture, update it! 
echo "update networking files for vmware8..."
sudo cat "$net_dir/networking.bak" | sed 's/\(VNET_8_HOSTONLY_SUBNET\) \([1-9]\{1,\}\.\)\{3\}/\1 '$ip'./g' >> "$net_dir/networking"

echo 'update subnet for hdcpd.conf...'
regex_str="s/\([1-9]\{1,\}\.\)\{3\}/'${ip}.'/g"
sudo cat "$dhcp_dir/dhcpd.conf.bak" | sed 's/\([1-9]\{1,\}\.\)\{3\}/'$ip'./g' >> "$dhcp_dir/dhcpd.conf"

# show info to prompt user for setting or updating static gateway and static dns 
# in mac: \033[1;31m  1; must exist
echo -e "\033[1;31m Set IP SubNet: $ip \033[0m"
echo -e "\033[1;31m If you set static ip, please set or update your linux gatway and dns: $ip.2 \033[0m"
echo -e "\033[1;31m Please quit completely your vmware fusion and restart it. \033[0m"
```

## 4.2 创建脚本并设置权限

```shell
# 1.创建脚本， 个人用户目即可
touch modify_vm8.sh

# 2. 拷贝上面的内容到我们刚创建的文件

# 3. 给脚本授权
sudo chmod a+x modify_vm8.sh

# 4. 如果脚本运行提示错误  /bin/bash^M: bad interpreter:
# 转化下文件格式解决 
dos2unix modify_vm8.sh

# 补充说明： 
# 1. dos2unix 可能没安装 需要我们安装下
brew install dos2unix

# 2. 如果brew也没安装 可以参考这个安装， 如果默认源不可以用请下载离线版本的安装
https://brew.sh/zh-cn/  
```



## 4.3 执行脚本更新vm8网卡网段

```shell
# 注意： 配置完后需要重启的vmware才能生效
sudo modify_vm8.sh

```

![image-20251015155604408](images/MacFusion网卡配置/image-20251015155604408.png)

