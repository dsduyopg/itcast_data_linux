﻿# ============================================================
# Git 自动同步工具包 - Git 运行环境探测
# 兼容 Git 不在系统 PATH、由管理员 PowerShell 启动等场景
# ============================================================

function Initialize-GitEnvironment {
    $candidates = New-Object System.Collections.ArrayList
    $seen = @{}

    function Add-GitCandidate {
        param([string]$Path)
        if ([string]::IsNullOrWhiteSpace($Path)) { return }
        $full = [System.IO.Path]::GetFullPath($Path.Trim().Trim('"'))
        $key = $full.ToLowerInvariant()
        if (-not $seen.ContainsKey($key)) {
            $seen[$key] = $true
            [void]$candidates.Add($full)
        }
    }

    # 当前 PATH 或命令缓存中已经能找到时优先使用
    $cmd = Get-Command git.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cmd) { Add-GitCandidate $cmd.Source }
    if ($env:GIT_INSTALL_ROOT) {
        Add-GitCandidate (Join-Path $env:GIT_INSTALL_ROOT 'cmd\git.exe')
        Add-GitCandidate (Join-Path $env:GIT_INSTALL_ROOT 'bin\git.exe')
    }

    # Git for Windows 安装器会记录实际安装目录，可覆盖非默认盘符
    $gitRegistryKeys = @(
        'HKLM:\SOFTWARE\GitForWindows',
        'HKCU:\SOFTWARE\GitForWindows',
        'HKLM:\SOFTWARE\WOW6432Node\GitForWindows'
    )
    foreach ($regKey in $gitRegistryKeys) {
        try {
            $installPath = (Get-ItemProperty -LiteralPath $regKey -ErrorAction Stop).InstallPath
            if ($installPath) {
                Add-GitCandidate (Join-Path $installPath 'cmd\git.exe')
                Add-GitCandidate (Join-Path $installPath 'bin\git.exe')
            }
        } catch { }
    }

    # 常见安装位置和便携安装位置
    $standardRoots = @()
    if ($env:ProgramFiles) { $standardRoots += (Join-Path $env:ProgramFiles 'Git') }
    if (${env:ProgramFiles(x86)}) { $standardRoots += (Join-Path ${env:ProgramFiles(x86)} 'Git') }
    if ($env:LOCALAPPDATA) { $standardRoots += (Join-Path $env:LOCALAPPDATA 'Programs\Git') }
    if ($env:USERPROFILE) { $standardRoots += (Join-Path $env:USERPROFILE 'scoop\apps\git\current') }
    if ($env:ProgramData) { $standardRoots += (Join-Path $env:ProgramData 'chocolatey\lib\git') }
    foreach ($root in $standardRoots) {
        if (-not $root) { continue }
        Add-GitCandidate (Join-Path $root 'cmd\git.exe')
        Add-GitCandidate (Join-Path $root 'bin\git.exe')
    }

    # 最后使用 where.exe 扫描当前进程 PATH
    try {
        $whereGit = Get-Command where.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($whereGit) {
            foreach ($line in @(& $whereGit.Source git.exe 2>$null)) {
                if ($line) { Add-GitCandidate $line.Trim() }
            }
        }
    } catch { }

    foreach ($candidate in $candidates) {
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        try {
            $version = (& $candidate --version 2>$null)
            if ($LASTEXITCODE -eq 0 -and $version -match '^git version') {
                $gitDir = Split-Path -Parent $candidate
                $pathParts = @($env:Path -split ';' | Where-Object { $_ })
                if ($pathParts -notcontains $gitDir) {
                    $env:Path = "$gitDir;$env:Path"
                }

                # 让 ssh / ssh-keygen 也能使用 Git 自带的版本
                $gitRoot = Split-Path -Parent $gitDir
                $gitUsrBin = Join-Path $gitRoot 'usr\bin'
                if ((Test-Path -LiteralPath (Join-Path $gitUsrBin 'ssh.exe')) -and (@($env:Path -split ';') -notcontains $gitUsrBin)) {
                    $env:Path = "$env:Path;$gitUsrBin"
                }
                return $candidate
            }
        } catch { }
    }

    return $null
}

function Test-GitAutoSyncEnvironment {
    param(
        [string]$TargetPath = '',
        [string]$SshKeyPath = '',
        [string]$NssmPath = '',
        [string]$RemoteUrl = '',
        [switch]$RequireAdmin
    )

    $checks = New-Object System.Collections.ArrayList
    function Add-EnvCheck {
        param(
            [string]$Name,
            [bool]$Passed,
            [string]$Detail,
            [bool]$Required = $true
        )
        [void]$checks.Add([pscustomobject]@{
            Check = $Name
            Result = if ($Passed) { '通过' } elseif ($Required) { '失败' } else { '提示' }
            Required = $Required
            Passed = $Passed
            Detail = $Detail
        })
    }

    $osVersion = [Environment]::OSVersion.Version
    Add-EnvCheck 'Windows 版本' ([Environment]::OSVersion.Platform -eq 'Win32NT' -and $osVersion.Major -ge 10) ("{0}.{1}.{2}" -f $osVersion.Major, $osVersion.Minor, $osVersion.Build)
    Add-EnvCheck 'PowerShell' ($PSVersionTable.PSVersion -ge [version]'5.1') $PSVersionTable.PSVersion.ToString()

    $gitExe = Initialize-GitEnvironment
    $gitVersion = ''
    if ($gitExe) {
        try { $gitVersion = (& $gitExe --version 2>$null) } catch { $gitVersion = '' }
    }
    Add-EnvCheck 'Git' ([bool]$gitExe -and $gitVersion -match '^git version') $(if ($gitExe) { "$gitVersion [$gitExe]" } else { '未找到，请安装 Git for Windows' })

    $sshExe = Get-Command ssh.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    Add-EnvCheck 'OpenSSH' ([bool]$sshExe) $(if ($sshExe) { $sshExe.Source } else { '未找到 ssh.exe' })

    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    Add-EnvCheck '管理员权限' $isAdmin $(if ($isAdmin) { '是' } else { '否；配置可继续，安装/修复服务时需要' }) ([bool]$RequireAdmin)

    if ($SshKeyPath) {
        $keyOk = (Test-Path -LiteralPath ($SshKeyPath -replace '/', '\') -PathType Leaf)
        Add-EnvCheck 'SSH 私钥' $keyOk $SshKeyPath
    }

    if ($NssmPath) {
        Add-EnvCheck 'NSSM' (Test-Path -LiteralPath $NssmPath -PathType Leaf) $NssmPath
    }

    if ($TargetPath) {
        $targetOk = Test-Path -LiteralPath $TargetPath -PathType Container
        $targetDetail = $TargetPath
        if ($targetOk) {
            $probe = Join-Path $TargetPath ('.git_autosync_write_test_' + [guid]::NewGuid().ToString('N'))
            try {
                [System.IO.File]::WriteAllText($probe, 'test')
                $targetOk = Test-Path -LiteralPath $probe
            } catch {
                $targetOk = $false
            } finally {
                if (Test-Path -LiteralPath $probe) { Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue }
            }
        }
        Add-EnvCheck '目标目录可写' $targetOk $targetDetail
    }

    if ($RemoteUrl) {
        $remoteOk = $false
        $remoteDetail = $RemoteUrl
        $remoteRefs = @()
        if ($gitExe) {
            $oldSshCommand = $env:GIT_SSH_COMMAND
            try {
                if ($SshKeyPath -and (Test-Path -LiteralPath ($SshKeyPath -replace '/', '\'))) {
                    $env:GIT_SSH_COMMAND = "ssh -i `"$($SshKeyPath -replace '\\','/')`" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new -o BatchMode=yes -o ConnectTimeout=15"
                }
                $remoteOutput = & $gitExe ls-remote --heads $RemoteUrl 2>&1
                $remoteOk = ($LASTEXITCODE -eq 0)
                if (-not $remoteOk) { $remoteDetail = ($remoteOutput -join ' ') }
                else {
                    $remoteRefs = @($remoteOutput | ForEach-Object {
                        if ("$_" -match '\s(refs/heads/.+)$') { $Matches[1] }
                    })
                }
            } catch {
                $remoteDetail = "$_"
            } finally {
                $env:GIT_SSH_COMMAND = $oldSshCommand
            }
        }
        Add-EnvCheck '远端连接/认证' $remoteOk $remoteDetail
    }

    $requiredFailures = @($checks | Where-Object { $_.Required -and -not $_.Passed })
    return [pscustomobject]@{
        AllPassed = ($requiredFailures.Count -eq 0)
        HasWarnings = (@($checks | Where-Object { -not $_.Required -and -not $_.Passed }).Count -gt 0)
        GitExe = $gitExe
        RemoteRefs = @($remoteRefs)
        Results = @($checks)
    }
}
