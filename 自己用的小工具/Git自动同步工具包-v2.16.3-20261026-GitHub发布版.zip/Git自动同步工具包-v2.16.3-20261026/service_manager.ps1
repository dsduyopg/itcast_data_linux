﻿# Git 自动同步工具包 · 服务管理菜单

$ErrorActionPreference = 'Continue'
$gitHelper = Join-Path $PSScriptRoot 'Initialize-GitEnvironment.ps1'
if (Test-Path -LiteralPath $gitHelper) {
    . $gitHelper
    $null = Initialize-GitEnvironment
}
$pathSafety = Join-Path $PSScriptRoot 'ServicePathSafety.ps1'
if (-not (Test-Path -LiteralPath $pathSafety)) {
    Write-Host '[错误] 缺少 ServicePathSafety.ps1，出于安全考虑服务管理已停止。' -ForegroundColor Red
    Read-Host '按回车退出'
    exit 1
}
. $pathSafety
$nssm = Join-Path $PSScriptRoot '04-一键部署\nssm_bin\nssm.exe'
if (-not (Test-Path -LiteralPath $nssm)) { $nssm = 'C:\nssm\nssm.exe' }

function Get-SyncServices {
    Get-Service -Name 'GitAutoSync*','GitMirrorFetcher' -ErrorAction SilentlyContinue | Sort-Object Name
}

function Get-RepoPathFromService {
    param([System.ServiceProcess.ServiceController]$svc)
    if (Get-Command Get-ServiceRepositoryPath -ErrorAction SilentlyContinue) {
        return Get-ServiceRepositoryPath -ServiceName $svc.Name
    }
    return $null
}

function Show-Status {
    Write-Host ''
    Write-Host '--- 同步服务状态 ---'
    $s = Get-SyncServices
    if (-not $s) {
        Write-Host '未找到同步服务，请先使用 新建自动推送仓库 或 安装定时拉取服务'
    } else {
        $s | Format-Table Status,Name -AutoSize
    }
    Write-Host ''
    Read-Host '按回车返回菜单'
}

function Start-All {
    Write-Host ''
    $s = Get-SyncServices
    if (-not $s) {
        Write-Host '未找到同步服务，请先使用 新建自动推送仓库 或 安装定时拉取服务'
    }
    foreach ($x in $s) {
        if ($x.Status -ne 'Running') {
            Start-Service $x.Name -ErrorAction Continue
            Write-Host "已启动: $($x.Name)"
        } else {
            Write-Host "已在运行: $($x.Name)"
        }
    }
    Write-Host ''
    Read-Host '按回车返回菜单'
}

function Stop-All {
    Write-Host ''
    $s = Get-SyncServices
    if (-not $s) {
        Write-Host '未找到同步服务'
    }
    foreach ($x in $s) {
        Stop-Service $x.Name -Force -ErrorAction SilentlyContinue
        Write-Host "已停止: $($x.Name)"
    }
    Write-Host ''
    Read-Host '按回车返回菜单'
}

function Select-Service {
    $s = Get-SyncServices
    if (-not $s) {
        Write-Host '未找到同步服务'
        Read-Host '按回车返回菜单'
        return $null
    }
    Write-Host '可操作的同步服务：'
    for ($i = 0; $i -lt $s.Count; $i++) {
        Write-Host ("  [{0}] {1}  {2}" -f ($i + 1), $s[$i].Name, $s[$i].Status)
        $repo = Get-RepoPathFromService -svc $s[$i]
        if ($repo) { Write-Host "      仓库路径: $repo" }
        else { Write-Host '      仓库路径: 未识别（不会自动删除目录）' -ForegroundColor Yellow }
    }
    $pick = Read-Host '请输入服务编号'
    $idx = 0
    if (-not [int]::TryParse($pick, [ref]$idx) -or $idx -lt 1 -or $idx -gt $s.Count) {
        Write-Host '编号无效'
        Read-Host '按回车返回菜单'
        return $null
    }
    return $s[$idx - 1]
}

function Start-One {
    Write-Host ''
    $svc = Select-Service
    if ($null -eq $svc) { return }
    if ($svc.Status -ne 'Running') {
        Start-Service $svc.Name -ErrorAction Continue
        Write-Host "已启动: $($svc.Name)"
    } else {
        Write-Host "已在运行: $($svc.Name)"
    }
    Read-Host '按回车返回菜单'
}

function Stop-One {
    Write-Host ''
    $svc = Select-Service
    if ($null -eq $svc) { return }
    Stop-Service $svc.Name -Force -ErrorAction SilentlyContinue
    Write-Host "已停止: $($svc.Name)"
    Read-Host '按回车返回菜单'
}

function Restart-One {
    Write-Host ''
    $svc = Select-Service
    if ($null -eq $svc) { return }
    $repo = Get-RepoPathFromService -svc $svc
    if ($repo) { Write-Host "仓库路径: $repo" }
    Write-Host "正在重启: $($svc.Name) ..."
    Stop-Service $svc.Name -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 500
    Start-Service $svc.Name -ErrorAction Continue
    Start-Sleep -Milliseconds 500
    $after = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
    if ($after -and $after.Status -eq 'Running') {
        Write-Host "已重启并运行: $($svc.Name)"
    } elseif ($after -and $after.Status -eq 'Stopped') {
        Write-Host "服务已停止，启动失败或已被禁用，请查看日志"
    } else {
        Write-Host "重启完成，请按 [1] 查看状态确认"
    }
    Read-Host '按回车返回菜单'
}

function Remove-One {
    Write-Host ''
    $s = Get-SyncServices
    if (-not $s) {
        Write-Host '未找到同步服务'
        Read-Host '按回车返回菜单'
        return
    }
    Write-Host '可卸载的同步服务：'
    for ($i = 0; $i -lt $s.Count; $i++) {
        Write-Host ("  [{0}] {1}  {2}" -f ($i + 1), $s[$i].Name, $s[$i].Status)
    }
    $pick = Read-Host '请输入要卸载的服务编号'
    $idx = 0
    if (-not [int]::TryParse($pick, [ref]$idx) -or $idx -lt 1 -or $idx -gt $s.Count) {
        Write-Host '编号无效'
        Read-Host '按回车返回菜单'
        return
    }
    $svc = $s[$idx - 1]
    if ($svc.Name -eq 'GitMirrorFetcher') {
        Write-Host 'GitMirrorFetcher 管理多个镜像目录，请先编辑 %USERPROFILE%\git_mirror_config.txt 删除对应行，再使用 [6] 卸载该服务。'
        Read-Host '按回车返回菜单'
        return
    }

    $repo = Get-RepoPathFromService -svc $svc
    $deleteCheck = if ($repo) { Test-SafeRepositoryDeletionPath -Path $repo } else { $null }
    $deleteRequested = [bool]($deleteCheck -and $deleteCheck.Safe)

    Write-Host ''
    Write-Host "服务    : $($svc.Name)"
    if ($deleteRequested) {
        $repo = $deleteCheck.Path
        Write-Host "仓库路径: $repo"
        Write-Host '将执行：停止服务 -> 卸载服务 -> 校验后删除本地 Git 仓库'
        Write-Host '云端仓库不受影响。'
    } else {
        if ($repo) {
            Write-Host "解析到的路径: $repo"
            Write-Host "安全检查结果: 禁止删除（$($deleteCheck.Reason)）" -ForegroundColor Yellow
        } else {
            Write-Host '仓库路径: 未识别' -ForegroundColor Yellow
        }
        Write-Host '将执行：停止服务 -> 卸载服务。不会删除任何本地目录。' -ForegroundColor Yellow
    }
    $confirm = Read-Host '确认执行？此操作不可恢复 (Y/N)'
    if ($confirm -notmatch '^[Yy]') {
        Write-Host '已取消'
        Read-Host '按回车返回菜单'
        return
    }

    if ($deleteRequested) {
        $leaf = Split-Path -Path $repo -Leaf
        $typed = (Read-Host "为避免误删，请输入仓库目录名「$leaf」确认删除").Trim()
        if ($typed -cne $leaf) {
            Write-Host '目录名不匹配，已取消。未卸载服务，也未删除任何文件。' -ForegroundColor Yellow
            Read-Host '按回车返回菜单'
            return
        }
    }

    Stop-Service $svc.Name -Force -ErrorAction SilentlyContinue
    try {
        if (Test-Path -LiteralPath $nssm -PathType Leaf) {
            & $nssm remove $svc.Name confirm 2>&1 | Out-Null
        }
    } catch { }
    Start-Sleep -Seconds 1
    if (Get-Service -Name $svc.Name -ErrorAction SilentlyContinue) {
        & sc.exe delete $svc.Name 2>&1 | Out-Null
        Start-Sleep -Seconds 1
    }

    if (Get-Service -Name $svc.Name -ErrorAction SilentlyContinue) {
        Write-Host '[警告] 服务卸载未完成，为避免数据损坏，没有删除任何目录。' -ForegroundColor Red
        Read-Host '按回车返回菜单'
        return
    }

    $deleted = $false
    if ($deleteRequested) {
        # 删除前再次校验，防止路径在确认后被替换
        $recheck = Test-SafeRepositoryDeletionPath -Path $repo
        if (-not $recheck.Safe) {
            Write-Host "[警告] 删除前复核失败（$($recheck.Reason)），本地目录保持不动。" -ForegroundColor Yellow
        } elseif (Test-Path -LiteralPath $recheck.Path) {
            try {
                Remove-Item -LiteralPath $recheck.Path -Recurse -Force -ErrorAction Stop
                $deleted = $true
            } catch {
                Write-Host "[警告] 本地目录删除失败：$_" -ForegroundColor Yellow
            }
        }
    }

    $cfg = Join-Path $env:USERPROFILE 'git_mirror_config.txt'
    if ($repo -and (Test-Path -LiteralPath $cfg)) {
        $lines = [System.IO.File]::ReadAllLines($cfg)
        $keep = @($lines | Where-Object { ($_ -split '\|')[0].Trim() -ne $repo })
        if ($keep.Count -ne $lines.Count) {
            [System.IO.File]::WriteAllLines($cfg, $keep, (New-Object System.Text.UTF8Encoding($false)))
            Write-Host "已清理镜像配置: $repo"
        }
    }

    Write-Host ''
    Write-Host "[OK] 服务已卸载: $($svc.Name)"
    if ($deleteRequested -and $deleted) {
        Write-Host "[OK] 本地 Git 仓库已删除: $repo"
    } elseif ($deleteRequested) {
        Write-Host '[提示] 服务已卸载，但本地目录未删除。请关闭占用该目录的程序后再手动处理。'
    } else {
        Write-Host '[提示] 未删除本地目录，以免服务配置异常时误删系统文件。'
    }
    Read-Host '按回车返回菜单'
}

function Repair-All {
    Write-Host ''
    Write-Host '正在修复所有同步服务...'
    & (Join-Path $PSScriptRoot '03-修复与重建\修复服务.bat')
}

function Rebuild-All {
    Write-Host ''
    Write-Host '正在彻底重建所有同步服务...'
    & (Join-Path $PSScriptRoot '03-修复与重建\彻底重建服务.bat')
}

function Uninstall-All {
    Write-Host ''
    $s = Get-SyncServices
    if (-not $s) {
        Write-Host '未找到同步服务'
        Read-Host '按回车返回菜单'
        return
    }
    Write-Host '以下服务将被停止并卸载:'
    $s | Select-Object Name | Format-Table -AutoSize
    $confirm = Read-Host '确认卸载全部同步服务？(Y/N)'
    if ($confirm -notmatch '^[Yy]') {
        Write-Host '已取消'
        Read-Host '按回车返回菜单'
        return
    }
    foreach ($x in $s) {
        Stop-Service $x.Name -Force -ErrorAction SilentlyContinue
        & $nssm remove $x.Name confirm | Out-Null
        Write-Host "已卸载: $($x.Name)"
    }
    Write-Host ''
    Read-Host '按回车返回菜单'
}

function Set-Interval {
    Write-Host ''
    $settings = Join-Path $env:USERPROFILE 'git_mirror_settings.txt'
    $current = 60
    if (Test-Path -LiteralPath $settings) {
        Get-Content -LiteralPath $settings -Encoding UTF8 | ForEach-Object {
            if ($_ -match '^interval\s*=\s*(\d+)$') { $current = [int]$Matches[1] }
        }
    }
    Write-Host "当前定时拉取间隔: $current 分钟"
    $mins = (Read-Host '新的间隔分钟数 (1-1440, 回车默认 60): ').Trim()
    if (-not $mins) { $mins = '60' }
    $n = 0
    if (-not [int]::TryParse($mins, [ref]$n) -or $n -lt 1 -or $n -gt 1440) {
        Write-Host '输入无效，请输入 1-1440 之间的分钟数'
        Read-Host '按回车返回菜单'
        return
    }
    $content = "interval=$n`r`n"
    [System.IO.File]::WriteAllText($settings, $content, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "已保存: interval=$n 分钟"
    $svc = Get-Service -Name 'GitMirrorFetcher' -ErrorAction SilentlyContinue
    if ($svc) {
        Stop-Service $svc.Name -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 500
        Start-Service $svc.Name -ErrorAction SilentlyContinue
        Write-Host 'GitMirrorFetcher 已重启，新间隔立即生效'
    } else {
        Write-Host '提示: GitMirrorFetcher 服务未安装，请先按 A 安装'
    }
    Read-Host '按回车返回菜单'
}

function Open-Docs {
    Start-Process (Join-Path $PSScriptRoot 'docs\0基础入门.md')
}

function Exclude-PushPath {
    Write-Host ''
    & (Join-Path $PSScriptRoot '移除推送目录.bat')
    Read-Host '按回车返回菜单'
}

function Show-About {
    Write-Host ''
    Write-Host 'Git 自动同步工具包 v2.16.3（通用发布版）'
    Write-Host '作者: wowsony'
    Write-Host '仓库: https://github.com/dsduyopg/git_auto'
    Write-Host '反馈: 请在 GitHub Issues 提交问题'
    Write-Host '本工具采用 MIT 许可证，欢迎学习使用；请保留作者与来源信息。'
    Read-Host '按回车返回菜单'
}

function Repair-Push {
    Write-Host ''
    Write-Host '--- 推送故障修复 ---'
    Write-Host '适用：仓库里有超过 100MB 的大文件（Gitee / GitHub 单文件上限 100MB），'
    Write-Host '      导致推送一直失败、远端报 exceeds file size limit / pre-receive hook declined。'
    Write-Host ''
    Write-Host '会做的事：停止服务 -> 备份当前提交 -> 排除 >95MB 大文件 -> 把未推送的提交压成 1 个干净的提交 -> 推送'
    Write-Host '大文件只从 Git 里排除，磁盘上的文件不会被删除。'
    Write-Host ''
    $all = Join-Path $PSScriptRoot '06-推送故障修复\fix_push_all.ps1'
    $one = Join-Path $PSScriptRoot '06-推送故障修复\fix_push_largefiles.ps1'
    if (-not (Test-Path -LiteralPath $all)) {
        Write-Host "找不到修复脚本：$all"
        Write-Host '请确认工具包完整，或在管理员 PowerShell 中运行 06-推送故障修复\fix_push_all.ps1'
        Read-Host '按回车返回菜单'
        return
    }
    Write-Host '  [1] 修复所有同步仓库（推荐）'
    Write-Host '  [2] 只修复指定仓库'
    $sel = Read-Host '请选择 (回车默认 1)'
    if ($sel -eq '2') {
        $svc = Select-Service
        if ($null -eq $svc) { return }
        $repo = Get-RepoPathFromService -svc $svc
        if (-not $repo -or -not (Test-Path -LiteralPath (Join-Path $repo '.git'))) {
            Write-Host "无法解析仓库路径或该目录不是 Git 仓库：$repo"
            Read-Host '按回车返回菜单'
            return
        }
        Write-Host ''
        Write-Host "即将修复：$repo"
        & powershell -NoProfile -ExecutionPolicy Bypass -File $one -RepoPath $repo
    } else {
        & powershell -NoProfile -ExecutionPolicy Bypass -File $all
    }
    Write-Host ''
    Read-Host '按回车返回菜单'
}
while ($true) {
    Clear-Host
    Write-Host '============================================'
    Write-Host '   Git 自动同步 · 服务管理'
    Write-Host '============================================'
    Write-Host '   [1] 查看服务状态'
    Write-Host '   [2] 启动所有同步服务'
    Write-Host '   [3] 停止所有同步服务'
    Write-Host '   [4] 修复所有同步服务'
    Write-Host '   [5] 彻底重建所有同步服务'
    Write-Host '   [6] 卸载所有同步服务'
    Write-Host '   [7] 打开使用文档'
    Write-Host '   [8] 新建自动推送仓库'
    Write-Host '   [9] 新建云端镜像拉取'
    Write-Host '   [A] 安装定时拉取服务'
    Write-Host '   [B] 生成 SSH 密钥'
    Write-Host '   [C] 启动指定服务'
    Write-Host '   [D] 停止指定服务'
    Write-Host '   [R] 重启指定服务（重载脚本）'
    Write-Host '   [E] 卸载指定服务（安全校验后删除仓库）'
    Write-Host '   [F] 设置定时拉取间隔'
    Write-Host '   [H] 删除/排除仓库里的子目录'
    Write-Host '   [P] 推送故障修复（排除大文件）'
    Write-Host '   [G] 关于本工具'
    Write-Host '   [M] 邮件通知配置（SMTP 总开关）'
    Write-Host '   [I] 邮件服务管理（按仓库开关·推荐）'
    Write-Host '   [N] 为指定仓库开启/升级邮件通知（旧版方式）'
    Write-Host '   [0] 退出'
    Write-Host ''
    $opt = Read-Host '请选择操作'
    switch ($opt) {
        '1' { Show-Status }
        '2' { Start-All }
        '3' { Stop-All }
        '4' { Repair-All }
        '5' { Rebuild-All }
        '6' { Uninstall-All }
        '7' { Open-Docs }
        '8' { & (Join-Path $PSScriptRoot '新建自动推送仓库.bat') }
        '9' { & (Join-Path $PSScriptRoot '新建云端镜像拉取.bat') }
        'A' { & (Join-Path $PSScriptRoot '安装定时拉取服务.bat') }
        'B' { & (Join-Path $PSScriptRoot '生成SSH密钥.bat') }
        'C' { Start-One }
        'D' { Stop-One }
        'R' { Restart-One }
        'E' { Remove-One }
        'F' { Set-Interval }
        'H' { Exclude-PushPath }
        'P' { Repair-Push }
        'G' { Show-About }
        'M' { & (Join-Path $PSScriptRoot '邮件通知配置.bat') }
        'I' { & (Join-Path $PSScriptRoot 'manage_mail_service.ps1') }
        'N' { & (Join-Path $PSScriptRoot '05-邮件通知\enable_mail_on_service.ps1'); Read-Host '按回车返回菜单' }
        '0' { break }
        default { Write-Host '输入无效，请重新选择'; Start-Sleep -Milliseconds 800 }
    }
}
