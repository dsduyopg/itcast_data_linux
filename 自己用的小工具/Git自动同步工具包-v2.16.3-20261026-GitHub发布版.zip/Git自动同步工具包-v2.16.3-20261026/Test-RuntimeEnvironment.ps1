﻿# ============================================================
# Git 自动同步工具包 - 运行环境自检
# ============================================================

param([switch]$RequireAdmin)

$helper = Join-Path $PSScriptRoot 'Initialize-GitEnvironment.ps1'
if (-not (Test-Path -LiteralPath $helper)) {
    Write-Host '[失败] 缺少 Initialize-GitEnvironment.ps1，工具包不完整。' -ForegroundColor Red
    exit 1
}

. $helper
$result = Test-GitAutoSyncEnvironment -RequireAdmin:$RequireAdmin
$result.Results | Format-Table Check,Result,Detail -AutoSize

if (-not $result.AllPassed) {
    Write-Host ''
    Write-Host '环境检查未通过。请先修复标为“失败”的项目。' -ForegroundColor Red
    exit 1
}

Write-Host ''
Write-Host '运行环境检查通过。' -ForegroundColor Green
exit 0
