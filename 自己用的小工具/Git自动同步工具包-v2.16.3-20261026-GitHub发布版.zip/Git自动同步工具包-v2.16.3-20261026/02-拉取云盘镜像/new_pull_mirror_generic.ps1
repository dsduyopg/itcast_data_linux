﻿# ============================================================
# 新建云端拉取镜像工具 - 通用版 (new_pull_mirror_generic.ps1)
# 任意远端仓库 -> 克隆/更新到任意指定路径
# 可选择 ~/.ssh 下的 SSH 密钥,并把密钥记入配置文件
# ============================================================

$ErrorActionPreference = 'Continue'

$gitHelper = Join-Path (Split-Path $PSScriptRoot -Parent) 'Initialize-GitEnvironment.ps1'
if (-not (Test-Path -LiteralPath $gitHelper)) {
    Write-Host '[错误] 工具包不完整，缺少 Initialize-GitEnvironment.ps1'
    Read-Host '按回车退出'
    exit 1
}
. $gitHelper
$environment = Test-GitAutoSyncEnvironment
$environment.Results | Format-Table Check,Result,Detail -AutoSize
if (-not $environment.AllPassed) {
    Write-Host '[错误] 运行环境检查未通过，已停止。' -ForegroundColor Red
    Read-Host '按回车退出'
    exit 1
}
$gitExe = $environment.GitExe

$ConfigFile = Join-Path $env:USERPROFILE 'git_mirror_config.txt'

# ---- 列出 SSH 私钥,让用户选择 ----
function Find-SshKeys {
    $sshDir = Join-Path $env:USERPROFILE '.ssh'
    if (Test-Path $sshDir) {
        return @(Get-ChildItem $sshDir -File | Where-Object {
            $_.Name -notlike '*.pub' -and $_.Name -notmatch 'known_hosts|config|authorized_keys'
        } | Select-Object -ExpandProperty FullName)
    }
    return @()
}
$keyList = @(Find-SshKeys)
if ($keyList.Count -eq 0) {
    Write-Host "[错误] 未找到 SSH 私钥。请先运行 生成SSH密钥.bat,或手动执行 ssh-keygen"
    Write-Host "      并把公钥(.pub)内容添加到你的 Gitee/GitHub 账号"
    exit 1
}
$sshKey = $null
if ($keyList.Count -eq 1) {
    $sshKey = $keyList[0]
} else {
    Write-Host "检测到以下 SSH 私钥,请选择本次拉取使用的密钥:"
    for ($i = 0; $i -lt $keyList.Count; $i++) {
        Write-Host ("  [{0}] {1}" -f ($i + 1), $keyList[$i])
    }
    $pick = (Read-Host '  请输入编号: ').Trim()
    $idx = 0
    if (-not [int]::TryParse($pick, [ref]$idx) -or $idx -lt 1 -or $idx -gt $keyList.Count) {
        Write-Host "[错误] 编号无效"
        exit 1
    }
    $sshKey = $keyList[$idx - 1]
}
$env:GIT_SSH_COMMAND = "ssh -i `"$($sshKey -replace '\\','/')`" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new -o BatchMode=yes -o ConnectTimeout=15"
Write-Host "[提示] 使用 SSH 密钥: $sshKey"

function Ask-Input($prompt) {
    Write-Host $prompt -NoNewline
    return (Read-Host).Trim()
}

Write-Host "=============================================="
Write-Host "  新建云端拉取镜像工具 (通用版)"
Write-Host "=============================================="

# 1. 远端地址
$remoteUrl = Ask-Input "1) 远端 SSH 地址 (如 git@gitee.com:user/repo.git): "
if (-not $remoteUrl) { Write-Host "[错误] 地址不能为空"; exit 1 }

# 2. GitHub 自动转 443
$isGitHub = $remoteUrl -match 'github'
if ($remoteUrl -match '^git@github\.com:(.+)$') {
    $remoteUrl = "ssh://git@ssh.github.com:443/$($Matches[1])"
    Write-Host "[提示] GitHub 已自动改用 443 端口"
}

# 3. 本地父目录；实际仓库目录是“父目录\远端仓库名”
$defaultName = ''
$remoteNameSource = $remoteUrl -replace '\\', '/'
if ($remoteNameSource -match '/([^/]+?)(?:\.git)?/?$') { $defaultName = $Matches[1] }
if (-not $defaultName) { $defaultName = 'mirror' }
if ($defaultName -match '[\\/:*?"<>|]') {
    Write-Host '[错误] 无法从远端地址解析出合法仓库名。'
    Read-Host '按回车退出'
    exit 1
}
$parentInput = Ask-Input "2) 本地父目录 (远端仓库将放在此目录下，回车默认当前目录): "
$parentDir = if ($parentInput) { $parentInput.TrimEnd('\', '/') } else { (Get-Location).Path }
try {
    $parentDir = [IO.Path]::GetFullPath($parentDir).TrimEnd('\')
} catch {
    Write-Host '[错误] 本地父目录路径无效。'
    Read-Host '按回车退出'
    exit 1
}
$parentLeaf = Split-Path -Path $parentDir -Leaf
$targetDir = if ($parentLeaf -ieq $defaultName) { $parentDir } else { Join-Path $parentDir $defaultName }
$targetDir = [IO.Path]::GetFullPath($targetDir).TrimEnd('\')
Write-Host "远端仓库名: $defaultName"
Write-Host "本地父目录: $parentDir"
Write-Host "实际仓库目录: $targetDir"

# 写入配置前先验证私钥和远端连接
$remoteCheck = Test-GitAutoSyncEnvironment -RemoteUrl $remoteUrl -SshKeyPath $sshKey
$remoteCheck.Results | Format-Table Check,Result,Detail -AutoSize
if (-not $remoteCheck.AllPassed) {
    Write-Host '[错误] SSH 私钥或远端连接检查未通过，未写入镜像配置。' -ForegroundColor Red
    Read-Host '按回车退出'
    exit 1
}

# 4. 根据远端真实分支选择默认值
$remoteBranches = @($remoteCheck.RemoteRefs | ForEach-Object {
    $_ -replace '^refs/heads/', ''
} | Where-Object { $_ } | Sort-Object -Unique)
$defaultBranch = if ($remoteBranches -contains 'main') { 'main' }
                 elseif ($remoteBranches -contains 'master') { 'master' }
                 elseif ($remoteBranches.Count -eq 1) { $remoteBranches[0] }
                 elseif ($isGitHub) { 'main' }
                 else { 'master' }
if ($remoteBranches.Count -gt 0) {
    Write-Host "远端现有分支: $($remoteBranches -join ', ')"
} else {
    Write-Host '远端当前为空仓库。'
}
$branch = Ask-Input "3) 分支 (回车默认: $defaultBranch): "
if (-not $branch) { $branch = $defaultBranch }
if ($remoteBranches.Count -gt 0 -and $branch -notin $remoteBranches) {
    Write-Host "[错误] 远端没有分支 $branch。请从现有分支中选择: $($remoteBranches -join ', ')" -ForegroundColor Red
    Read-Host '按回车退出'
    exit 1
}

# 5. 立即拉取
Write-Host "--- 立即拉取到 $targetDir ---"
$gitDir = Join-Path $targetDir '.git'
if (-not (Test-Path $parentDir)) {
    New-Item -ItemType Directory -Path $parentDir -Force -ErrorAction Stop | Out-Null
}
if (-not (Test-Path $gitDir)) {
    if ((Test-Path $targetDir) -and @(Get-ChildItem -LiteralPath $targetDir -Force).Count -gt 0) {
        Write-Host '[错误] 目标目录已存在、非空且不是 Git 仓库，为避免覆盖已停止。' -ForegroundColor Red
        Read-Host '按回车退出'
        exit 1
    }
    $out = git clone $remoteUrl $targetDir 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[错误] 克隆失败，未写入镜像配置。" -ForegroundColor Red
        $out | ForEach-Object { Write-Host "       $_" -ForegroundColor Red }
        Read-Host '按回车退出'
        exit 1
    }
    if ($remoteBranches.Count -gt 0) {
        $checkoutOut = git -C $targetDir checkout $branch 2>&1
        if ($LASTEXITCODE -ne 0) {
            Write-Host "[错误] 切换分支 $branch 失败，未写入镜像配置。" -ForegroundColor Red
            $checkoutOut | ForEach-Object { Write-Host "       $_" -ForegroundColor Red }
            Read-Host '按回车退出'
            exit 1
        }
    }
    Write-Host "[OK] 已克隆到 $targetDir"
} else {
    git -C $targetDir remote set-url origin $remoteUrl 2>&1 | Out-Null
    $fOut = git -C $targetDir fetch origin $branch 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[错误] 拉取失败，未写入镜像配置。" -ForegroundColor Red
        $fOut | ForEach-Object { Write-Host "       $_" -ForegroundColor Red }
        Read-Host '按回车退出'
        exit 1
    }
    git -C $targetDir reset --hard "origin/$branch" 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[错误] 更新本地分支失败，未写入镜像配置。" -ForegroundColor Red
        Read-Host '按回车退出'
        exit 1
    }
    Write-Host "[OK] 已更新到云端最新"
}

# 拉取成功后才登记镜像配置
if (-not (Test-Path $ConfigFile)) {
    New-Item -ItemType File -Path $ConfigFile -Force | Out-Null
}
$content = if (Test-Path $ConfigFile) { [System.IO.File]::ReadAllText($ConfigFile) } else { '' }
$entry = "$targetDir|$remoteUrl|$branch|$sshKey"
$key3 = "$targetDir|$remoteUrl|$branch"
$isDup = $content -split "`r?`n" | Where-Object { $t = $_.Trim(); $t -and (($t -split '\|')[0..2] -join '|') -eq $key3 }
if ($isDup) {
    Write-Host "[提示] 该镜像配置已存在，跳过重复登记"
} else {
    if ($content -and -not $content.EndsWith("`n")) { $content += "`n" }
    $content += "$entry`n"
    [System.IO.File]::WriteAllText($ConfigFile, $content, (New-Object System.Text.UTF8Encoding($false)))
}
Write-Host "[OK] 已登记: $targetDir  <-  $remoteUrl  ($branch)"

Write-Host ""
Write-Host "=============================================="
Write-Host "  完成! 配置保存在: $ConfigFile"
Write-Host "  (如需定时自动更新,可配合 change_fetcher 使用)"
Write-Host "=============================================="
