﻿# ============================================================
# Git 自动同步工具包 - 服务仓库路径解析与删除保护
# ============================================================

$script:ServicePathSafetyToolkitRoot = $PSScriptRoot

function Find-GitRepositoryRoot {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $null }

    try {
        $probe = [System.IO.Path]::GetFullPath($Path.Trim().Trim('"').Trim("'"))
        if ($probe -match '(?i)\.ps1$' -or (Test-Path -LiteralPath $probe -PathType Leaf)) {
            $probe = Split-Path -Parent $probe
        }
    } catch {
        return $null
    }

    while ($probe) {
        if (Test-Path -LiteralPath (Join-Path $probe '.git')) { return $probe.TrimEnd('\') }
        $parent = Split-Path -Parent $probe
        if (-not $parent -or $parent -eq $probe) { break }
        $probe = $parent
    }
    return $null
}

function Get-ServiceRepositoryPath {
    param(
        [string]$ServiceName,
        [string]$AppParameters,
        [string]$AppDirectory,
        [string]$Application
    )
    if ($ServiceName) {
        $params = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName\Parameters"
        if (-not (Test-Path -LiteralPath $params)) { return $null }
        $p = Get-ItemProperty -LiteralPath $params -ErrorAction SilentlyContinue
        $AppParameters = [string]$p.AppParameters
        $AppDirectory = [string]$p.AppDirectory
        $Application = [string]$p.Application
    }

    # AppParameters 指向生成的实际同步脚本，优先级高于 AppDirectory
    if ($AppParameters -and $AppParameters -match '(?i)-File\s+["'']?([^"'']+?\.ps1)') {
        $scriptPath = $Matches[1].Trim().Trim('"').Trim("'")
        $repo = Find-GitRepositoryRoot -Path $scriptPath
        if ($repo) { return $repo }
    }
    if ($Application -and $Application -match '(?i)\.ps1$') {
        $repo = Find-GitRepositoryRoot -Path $Application
        if ($repo) { return $repo }
    }
    if ($AppDirectory) {
        $repo = Find-GitRepositoryRoot -Path $AppDirectory
        if ($repo) { return $repo }
    }
    return $null
}

function Test-SafeRepositoryDeletionPath {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) {
        return [pscustomobject]@{ Safe = $false; Path = ''; Reason = '仓库路径为空' }
    }

    try {
        $full = [System.IO.Path]::GetFullPath($Path).TrimEnd('\')
    } catch {
        return [pscustomobject]@{ Safe = $false; Path = $Path; Reason = '路径格式无效' }
    }

    if (-not (Test-Path -LiteralPath $full -PathType Container)) {
        return [pscustomobject]@{ Safe = $false; Path = $full; Reason = '目录不存在' }
    }
    if (-not (Test-Path -LiteralPath (Join-Path $full '.git'))) {
        return [pscustomobject]@{ Safe = $false; Path = $full; Reason = '不是 Git 仓库' }
    }

    $item = Get-Item -LiteralPath $full -Force -ErrorAction SilentlyContinue
    if ($item -and (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0)) {
        return [pscustomobject]@{ Safe = $false; Path = $full; Reason = '目录是链接或重解析点' }
    }

    $driveRoot = [System.IO.Path]::GetPathRoot($full).TrimEnd('\')
    if ($full -eq $driveRoot) {
        return [pscustomobject]@{ Safe = $false; Path = $full; Reason = '不能删除磁盘根目录' }
    }

    # 这些父目录整棵子树都禁止作为“仓库删除目标”
    $blockedTrees = @(
        $env:SystemRoot,
        $env:ProgramFiles,
        ${env:ProgramFiles(x86)},
        $env:ProgramData,
        $env:LOCALAPPDATA,
        $env:APPDATA,
        $env:PUBLIC,
        $script:ServicePathSafetyToolkitRoot
    )
    foreach ($root in $blockedTrees) {
        if ([string]::IsNullOrWhiteSpace($root)) { continue }
        try { $rootFull = [System.IO.Path]::GetFullPath($root).TrimEnd('\') } catch { continue }
        if ($full -eq $rootFull -or $full.StartsWith($rootFull + '\', [StringComparison]::OrdinalIgnoreCase)) {
            return [pscustomobject]@{ Safe = $false; Path = $full; Reason = "位于受保护目录：$rootFull" }
        }
    }

    # 用户目录本身也禁止，但其下的 Documents、Projects 等普通目录允许
    foreach ($root in @($env:USERPROFILE, $env:SystemDrive)) {
        if ([string]::IsNullOrWhiteSpace($root)) { continue }
        try { $rootFull = [System.IO.Path]::GetFullPath($root).TrimEnd('\') } catch { continue }
        if ($full -eq $rootFull) {
            return [pscustomobject]@{ Safe = $false; Path = $full; Reason = "不能删除受保护目录：$rootFull" }
        }
    }

    return [pscustomobject]@{ Safe = $true; Path = $full; Reason = '' }
}
