﻿# ============================================================
#  Git 推送修复脚本（大文件导致推送失败）——支持任意仓库
#  需要管理员权限运行（要停止/重启同步服务）
#
#  原理：远端平台有单文件硬上限（Gitee 100MB / GitHub 100MB），
#        本地未推送的提交里只要有大文件，push 就会被远端拒收。
#        本脚本把这些未推送提交压成 1 个干净提交（排除超大文件）再推。
#
#  用法：
#    powershell -NoProfile -ExecutionPolicy Bypass -File fix_push_largefiles.ps1 -RepoPath "C:\path\to\repo"
#    或从 服务管理.bat -> [P] -> [2] 选择指定仓库
#
#  可选参数：
#    -RepoPath <路径>   仓库路径（未指定时运行后会提示输入）
#    -Branch <分支>     默认取仓库当前分支
#    -Remote <名称>     默认 origin
#    -SvcName <服务名>  默认按目录名匹配 GitAutoSync_<目录名>
#    -SyncPs1 <路径>    默认自动找仓库里的 git_sync_realtime_*.ps1
#    -ExcludeStage2     整个「第二阶段」目录不入库（本地保留）
#
#  本脚本不会删除任何磁盘文件。
# ============================================================

param(
    [string]$RepoPath = '',
    [string]$Branch   = '',
    [string]$Remote   = 'origin',
    [string]$SvcName  = '',
    [string]$SyncPs1  = '',
    [string]$LogFile  = '',
    [switch]$ExcludeStage2,
    [ValidateSet('ask','yes','no')][string]$Cleanup = 'ask',
    [ValidateSet('ask','yes','no')][string]$Restart = 'ask'
)

$ErrorActionPreference = 'Continue'

$gitHelper = Join-Path (Split-Path $PSScriptRoot -Parent) 'Initialize-GitEnvironment.ps1'
. $gitHelper
$environment = Test-GitAutoSyncEnvironment
if (-not $environment.AllPassed) {
    $environment.Results | Format-Table Check,Result,Detail -AutoSize
    Write-Host '[错误] 运行环境检查未通过，无法执行推送修复。'
    exit 1
}
$gitExe = $environment.GitExe

if ([string]::IsNullOrWhiteSpace($RepoPath)) {
    $RepoPath = (Read-Host '请输入需要修复的 Git 仓库路径').Trim().Trim('"')
}
if ([string]::IsNullOrWhiteSpace($RepoPath)) {
    Write-Host '未提供 Git 仓库路径，已取消。' -ForegroundColor Red
    exit 1
}
$RepoPath = [System.IO.Path]::GetFullPath($RepoPath)

$ToolkitRoot = Split-Path -Path $PSScriptRoot -Parent
$NssmCandidates = @(
    (Join-Path $ToolkitRoot '04-一键部署\nssm_bin\nssm.exe')
)
$Nssm = @($NssmCandidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1)
if (-not $Nssm) { $Nssm = '' }
$LimitMB  = 95
$maxBytes = $LimitMB * 1MB

$repoLeaf = Split-Path -Path $RepoPath -Leaf
if (-not $LogFile) { $LogFile = Join-Path (Split-Path -Path $RepoPath -Parent) "fix_push_$repoLeaf.log" }
if (-not $Branch) {
    $Branch = (git -C $RepoPath rev-parse --abbrev-ref HEAD 2>$null)
    if ([string]::IsNullOrWhiteSpace($Branch) -or $Branch -eq 'HEAD') { $Branch = 'main' }
}
if (-not $SvcName) {
    $cand = "GitAutoSync_$repoLeaf"
    if (Get-Service -Name $cand -ErrorAction SilentlyContinue) { $SvcName = $cand }
    else {
        $hit = Get-Service -Name 'GitAutoSync*' -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "*$repoLeaf*" } | Select-Object -First 1
        if ($hit) { $SvcName = $hit.Name }
    }
}
if (-not $SyncPs1) {
    $cands = @(Get-ChildItem -LiteralPath $RepoPath -Filter 'git_sync_realtime_*.ps1' -File -ErrorAction SilentlyContinue)
    $exact = @($cands | Where-Object { $_.Name -clike "*$repoLeaf*" })
    if ($exact.Count -gt 0)          { $SyncPs1 = ($exact  | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName }
    elseif ($cands.Count -gt 0)      { $SyncPs1 = ($cands  | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName }
}

function Write-Log {
    param([string]$Msg)
    $line = "[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg
    try { $line | Out-File -FilePath $LogFile -Append -Encoding utf8 } catch { }
    Write-Host $line
}

function Fail {
    param([string]$Msg)
    Write-Log "【失败】$Msg"
    Write-Host ''
    Write-Host "修复未完成。完整日志：$LogFile" -ForegroundColor Red
    Write-Host '请检查日志；如问题仍未解决，请在提交 Issue 时附上日志内容。' -ForegroundColor Yellow
    exit 1
}

function Get-StagedFiles {
    $prevEnc = [Console]::OutputEncoding
    try {
        [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
        return @(git -C $RepoPath -c core.quotePath=false diff --cached --name-only 2>$null)
    } finally {
        [Console]::OutputEncoding = $prevEnc
    }
}

# 把暂存区里超过 $LimitMB 的文件撤出暂存（磁盘文件保留），否则远端会拒收
function Remove-OversizeFromIndex {
    param([string]$Why)
    $hit = 0
    foreach ($rel in (Get-StagedFiles)) {
        if ([string]::IsNullOrWhiteSpace($rel)) { continue }
        $full = Join-Path $RepoPath ($rel -replace '/', '\')
        if (-not (Test-Path -LiteralPath $full)) { continue }
        $len = (Get-Item -LiteralPath $full).Length
        if ($len -gt $maxBytes) {
            git -C $RepoPath reset -q -- ":(literal)$rel" 2>&1 | Out-Null
            Write-Log ("  已排除超大文件（{0}，{1:N1}MB）：{2}" -f $Why, ($len / 1MB), $rel)
            $hit++
        }
    }
    if ($hit -eq 0) { Write-Log "  未发现超过 $LimitMB MB 的文件（$Why）" }
    return $hit
}

# 把 HEAD/暂存区回滚到修复前的备份提交（磁盘文件不动）
function Rollback-ToBackup {
    param([string]$Backup)
    if ([string]::IsNullOrWhiteSpace($Backup)) { return }
    git -C $RepoPath rev-parse --verify --quiet "refs/heads/$Backup" 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) {
        git -C $RepoPath reset --soft $Backup 2>&1 | Out-Null
        git -C $RepoPath reset -q 2>&1 | Out-Null
        Write-Log "已回滚到修复前状态：$Backup（磁盘文件未改动）"
    }
}

# ---------------- 0. 前置检查 ----------------
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host '本脚本需要管理员权限：请右键对应的 .bat -> 以管理员身份运行。' -ForegroundColor Red
    exit 1
}
if (-not (Test-Path -LiteralPath (Join-Path $RepoPath '.git'))) { Fail "不是 Git 仓库：$RepoPath" }

Write-Log '==================== 修复开始 ===================='
Write-Log "仓库：$RepoPath（分支 $Branch）  服务：$(if ($SvcName) { $SvcName } else { '未匹配到' })"

# ---------------- 1. 停止自动同步服务 ----------------
$svc = if ($SvcName) { Get-Service -Name $SvcName -ErrorAction SilentlyContinue } else { $null }
if ($svc) {
    Write-Log "停止自动同步服务：$SvcName"
    try {
        if (Test-Path -LiteralPath $Nssm) { & $Nssm stop $SvcName | Out-Null } else { Stop-Service -Name $SvcName -Force }
    } catch { Write-Log "停止服务出错（继续）：$_" }
    $deadline = (Get-Date).AddSeconds(60)
    while ((Get-Service -Name $SvcName).Status -ne 'Stopped' -and (Get-Date) -lt $deadline) { Start-Sleep -Seconds 2 }
    $st = (Get-Service -Name $SvcName).Status
    Write-Log "服务状态：$st"
    if ($st -ne 'Stopped') { Fail "无法停止服务 $SvcName，请先在同步工具里选 [D] 或 [3] 停止它再运行本脚本" }
} else {
    Write-Log "未匹配到同步服务（可能已停止或未安装），继续"
}

# ---------------- 2. 等残留 git/ssh 进程退出，清理锁 ----------------
$deadline = (Get-Date).AddSeconds(45)
$logged = $false
while ((Get-Date) -lt $deadline) {
    if (-not (Get-Process -Name git, ssh -ErrorAction SilentlyContinue)) { break }
    $busy = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
              Where-Object { ($_.Name -eq 'git.exe' -or $_.Name -eq 'ssh.exe') -and (-not $_.CommandLine -or $_.CommandLine -match [regex]::Escape($RepoPath)) })
    if ($busy.Count -eq 0) { break }
    if (-not $logged) {
        Write-Log "检测到仍在操作本仓库的 git 进程（PID $(($busy | ForEach-Object { $_.ProcessId }) -join ',')），等待其结束..."
        $logged = $true
    }
    Start-Sleep -Seconds 2
}
$lock = Join-Path $RepoPath '.git\index.lock'
if (Test-Path -LiteralPath $lock) {
    Remove-Item -LiteralPath $lock -Force -ErrorAction SilentlyContinue
    Write-Log '已清理残留的 index.lock'
}

# ---------------- 3. 备份当前提交 ----------------
$stamp        = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupBranch = "$repoLeaf-pre-fix-$stamp"
$oldHead      = (git -C $RepoPath rev-parse --short HEAD 2>$null)
git -C $RepoPath branch $backupBranch HEAD 2>&1 | Out-Null
if ($LASTEXITCODE -eq 0) { Write-Log "已备份当前提交 $oldHead 到分支：$backupBranch" }
else { Write-Log "备份分支创建失败（继续），当前提交：$oldHead" }

# ---------------- 4. 获取远程最新 ----------------
$fetched = $false
for ($i = 1; $i -le 3; $i++) {
    $fetchOut = git -C $RepoPath fetch $Remote $Branch 2>&1
    if ($LASTEXITCODE -eq 0) { $fetched = $true; break }
    Write-Log "连接远程失败（第 $i/3 次）：$fetchOut"
    Start-Sleep -Seconds 5
}
if (-not $fetched) { Fail '无法连接远程仓库（git fetch 失败），请检查网络后重试' }
Write-Log "已获取远程最新提交：$Remote/$Branch"

# ---------------- 5. 把未推送的提交压成待提交状态（工作区文件不动） ----------------
$tipLine = "$Remote/$Branch"
$aheadCount = @(git -C $RepoPath rev-list "$tipLine..HEAD").Count
git -C $RepoPath reset --soft $tipLine 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) { Fail "git reset --soft $tipLine 失败" }
Write-Log "已把本地 $aheadCount 个未推送提交（$oldHead）回退为待提交状态，磁盘文件未改动"

# ---------------- 6. 排除「第二阶段」/ 超大文件 ----------------
if ($ExcludeStage2) {
    $tracked2 = @(git -C $RepoPath ls-files -- '第二阶段')
    if ($tracked2.Count -gt 0) {
        git -C $RepoPath rm -r --cached --quiet -- '第二阶段' 2>&1 | Out-Null
        Write-Log "已把「第二阶段」撤出版本库（$($tracked2.Count) 个文件，磁盘文件未删除）"
    } else {
        Write-Log '「第二阶段」已不在版本库中（保持排除）'
    }
} else {
    Write-Log '未启用「第二阶段」整目录排除（本仓库只排除超大文件）'
}
Remove-OversizeFromIndex -Why '来自旧提交' | Out-Null

# ---------------- 7. 写入 .gitignore 规则 ----------------
$giPath  = Join-Path $RepoPath '.gitignore'
$giText  = ''
if (Test-Path -LiteralPath $giPath) { $giText = Get-Content -LiteralPath $giPath -Raw -Encoding UTF8 }
$newRules = @('# ==== 大文件保护：远端单文件上限 100MB，以下不入库（本地保留）====')
if ($ExcludeStage2) { $newRules += '第二阶段/' }
$newRules += @('*.tar.gz', '*.tar', '*.war')
$missing = @()
foreach ($r in $newRules) { if ($giText -notmatch [regex]::Escape($r)) { $missing += $r } }
if ($missing.Count -gt 0) {
    $append = ($missing -join "`r`n")
    if ($giText.Length -gt 0 -and -not $giText.EndsWith("`n")) { $append = "`r`n" + $append }
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($append + "`r`n")
    if (-not (Test-Path -LiteralPath $giPath)) {
        [System.IO.File]::WriteAllBytes($giPath, ([System.Text.Encoding]::UTF8.GetPreamble() + $bytes))
    } else {
        $fs = [System.IO.File]::Open($giPath, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write)
        $fs.Write($bytes, 0, $bytes.Length)
        $fs.Close()
    }
    Write-Log "已更新 .gitignore：`r`n$($missing -join "`r`n")"
} else {
    Write-Log '.gitignore 规则已存在，未重复写入'
}

# ---------------- 8. 给实时同步脚本加“超大文件自动跳过”兜底保护 ----------------
$guardMarker  = '大文件保护'
$guardMarker2 = '超标文件一律不入库'
if ($SyncPs1 -and (Test-Path -LiteralPath $SyncPs1)) {
    $text = Get-Content -LiteralPath $SyncPs1 -Raw -Encoding UTF8
    if (($text -match [regex]::Escape($guardMarker)) -and ($text -match [regex]::Escape($guardMarker2))) {
        Write-Log '同步脚本已含超大文件保护，跳过'
    } elseif ($text -match '(?m)^(?<line>.*git add 失败.*)$') {
        $anchor = $Matches['line']
        $guard = @'
        # ---- 大文件保护：远端单文件上限 100MB，超标文件一律不入库 ----
        $MaxFileMB = 95
        $prevEnc2 = [Console]::OutputEncoding
        try {
            [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
            $stagedFiles = @(git -C $RepoPath -c core.quotePath=false diff --cached --name-only 2>$null)
        } finally { [Console]::OutputEncoding = $prevEnc2 }
        foreach ($rel in $stagedFiles) {
            if ([string]::IsNullOrWhiteSpace($rel)) { continue }
            $full = Join-Path $RepoPath ($rel -replace '/', '\')
            if (-not (Test-Path -LiteralPath $full)) { continue }
            $len = (Get-Item -LiteralPath $full).Length
            if ($len -gt ($MaxFileMB * 1MB)) {
                git -C $RepoPath reset -q -- ":(literal)$rel" 2>&1 | Out-Null
                Write-Log ("已跳过超大文件（{0:N1}MB > {1}MB）：{2}" -f ($len / 1MB), $MaxFileMB, $rel)
            }
        }
'@
        $text = $text.Replace($anchor, $anchor + "`r`n" + $guard)
        [System.IO.File]::WriteAllText($SyncPs1, $text, (New-Object System.Text.UTF8Encoding($true)))
        Write-Log "已给同步脚本加上超大文件保护：$SyncPs1"
    } else {
        Write-Log '同步脚本结构已变化，未自动打补丁（.gitignore 规则仍然生效）'
    }
} else {
    Write-Log "未找到同步脚本（跳过补丁，.gitignore 规则仍然生效）"
}

# ---------------- 9. 重新暂存、兜底再排一次超大文件 ----------------
git -C $RepoPath add -A 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) { Fail 'git add -A 失败' }
Remove-OversizeFromIndex -Why '本次提交' | Out-Null

if ($ExcludeStage2) {
    $still2 = @(git -C $RepoPath -c core.quotePath=false diff --cached --name-status -- '第二阶段' 2>$null | Where-Object { $_ -match '^[AMRC]' })
    if ($still2.Count -gt 0) {
        Rollback-ToBackup $backupBranch
        Fail "暂存区里仍有「第二阶段」的新增/修改文件 $($still2.Count) 个，已回滚（未做任何提交）"
    }
}

$status = @(git -C $RepoPath status --porcelain)
if ($status.Count -eq 0) {
    Write-Log '暂存区没有需要提交的改动'
} else {
    $msg = '同步笔记：排除超过 100MB 的大文件，修复推送失败'
    $commitOut = git -C $RepoPath commit -m $msg 2>&1
    if ($LASTEXITCODE -ne 0) {
        Rollback-ToBackup $backupBranch
        Fail "git commit 失败：$commitOut"
    }
    Write-Log "已提交：$msg"
}

# ---------------- 10. 推送 ----------------
$pushed = $false
$pushOut = ''
for ($i = 1; $i -le 3; $i++) {
    $pushOut = git -C $RepoPath push $Remote $Branch 2>&1
    if ($LASTEXITCODE -eq 0) { $pushed = $true; break }
    Write-Log "推送失败（第 $i/3 次）：$pushOut"
    Start-Sleep -Seconds 8
}

if ($pushed) {
    Write-Log "推送成功 -> $Remote/$Branch"
} else {
    Write-Log "推送仍然失败：$pushOut"
    Write-Log "备份分支 $backupBranch 已保留（可用 git reset --hard $backupBranch 还原）"
}

Write-Log '当前提交：'
foreach ($l in (git -C $RepoPath log --oneline -3)) { Write-Log "  $l" }

# ---------------- 11. 可选：清理 .git 里已废弃的大文件 ----------------
if ($pushed) {
    if ($Cleanup -eq 'yes') { $ans = 'y' }
    elseif ($Cleanup -eq 'no') { $ans = 'n' }
    else {
        Write-Host ''
        $ans = Read-Host "推送成功。是否清理 .git 中已废弃的大文件对象以减小占用？(Y/n)"
    }
    if ($ans -notmatch '^[nN]') {
        $freeMb = -1
        try {
            $q = (Split-Path -Qualifier $RepoPath).TrimEnd(':')
            $freeMb = [math]::Round((Get-PSDrive -Name $q).Free / 1MB)
        } catch { }
        if ($freeMb -ge 0 -and $freeMb -lt 2000) {
            Write-Log "磁盘剩余空间仅 $freeMb MB，已跳过 .git 压缩以免写满磁盘；腾出空间后再执行： git -C `"$RepoPath`" gc --prune=now"
        } else {
            git -C $RepoPath branch -D $backupBranch 2>&1 | Out-Null
            git -C $RepoPath reflog expire --expire-unreachable=now --all 2>&1 | Out-Null
            Write-Log '正在压缩 .git（可能需要几分钟，请勿关闭窗口）...'
            git -C $RepoPath gc --prune=now --quiet 2>&1 | Out-Null
            $gitMb = [math]::Round(((Get-ChildItem (Join-Path $RepoPath '.git') -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1MB), 1)
            Write-Log "清理完成，.git 当前大小：$gitMb MB（已删除备份分支 $backupBranch）"
        }
    } else {
        Write-Log "已保留备份分支 $backupBranch（内含大文件对象，确认无误后可删）"
    }
}

# ---------------- 12. 是否恢复自动同步 ----------------
$svcNow = if ($SvcName) { Get-Service -Name $SvcName -ErrorAction SilentlyContinue } else { $null }
if ($svcNow) {
    if ($Restart -eq 'yes') { $ans2 = 'y' }
    elseif ($Restart -eq 'no') { $ans2 = 'n' }
    else {
        Write-Host ''
        $ans2 = Read-Host "是否重新启动自动同步服务？(Y=恢复后台自动推送 / N=保持停止，回车默认 N)"
    }
    if ($ans2 -match '^[yY]') {
        try {
            if (Test-Path -LiteralPath $Nssm) { & $Nssm start $SvcName | Out-Null } else { Start-Service -Name $SvcName }
        } catch { Write-Log "启动服务出错：$_" }
        $deadline = (Get-Date).AddSeconds(30)
        while ((Get-Service -Name $SvcName).Status -ne 'Running' -and (Get-Date) -lt $deadline) { Start-Sleep -Seconds 2 }
        Write-Log ("自动同步服务状态：" + (Get-Service -Name $SvcName).Status)
    } else {
        Write-Log "自动同步服务保持【停止】状态：后台不会再自动提交/推送。需要恢复时用同步工具菜单 [2] 或 [D]/[R]。"
    }
}

# ---------------- 13. 结果 ----------------
Write-Log '==================== 修复结束 ===================='
if ($pushed) {
    Write-Host ''
    Write-Host "✅ 已完成：$RepoPath 推送成功；超大文件保留在本地，未入库。" -ForegroundColor Green
} else {
    Write-Host ''
    Write-Host "⚠ 仍未推送成功，请检查日志并根据提示处理后重试：$LogFile" -ForegroundColor Yellow
}
