﻿# ============================================================
#  通用：一键诊断并修复"所有"自动同步仓库的推送问题
#  需要管理员权限（要停止/重启同步服务）
#
#  它做什么：
#    1. 扫描指定根目录下所有同步脚本，自动找出每个被同步的 Git 仓库
#    2. 逐个预检：能不能连上远程、有没有未推送提交 / 未提交改动
#    3. 有问题的仓库自动调用 fix_push_largefiles.ps1 修复并推送
#       （排除 >95MB 大文件、把未推送提交压成 1 个干净提交）
#    4. 全部处理完输出汇总表
#
#  用法：
#    powershell -File fix_push_all.ps1 -Root "D:\path\to\projects"
#    powershell -File fix_push_all.ps1 -Root "D:\path\to\projects" -AutoCleanup -AutoRestart
#    ... -KeepStopped                        <- 修完保持服务停止
#
#  对已经同步、没有问题的仓库只会报告"已同步"，不做任何改动。
# ============================================================

param(
    [string]$Root = '',
    [switch]$AutoCleanup,
    [switch]$AutoRestart,
    [switch]$KeepStopped
)

$ErrorActionPreference = 'Continue'
$gitHelper = Join-Path (Split-Path $PSScriptRoot -Parent) 'Initialize-GitEnvironment.ps1'
. $gitHelper
$environment = Test-GitAutoSyncEnvironment
if (-not $environment.AllPassed) {
    $environment.Results | Format-Table Check,Result,Detail -AutoSize
    Write-Host '[错误] 运行环境检查未通过，无法执行推送修复。'
    exit 1
}
$gitExe = $environment.GitExe
$Single      = Join-Path $PSScriptRoot 'fix_push_largefiles.ps1'
$LimitBytes  = 95MB
$Summary     = New-Object System.Collections.ArrayList

if ([string]::IsNullOrWhiteSpace($Root)) {
    $Root = (Read-Host '请输入要扫描的根目录（该目录下应为自动同步的项目）').Trim().Trim('"')
}
if ([string]::IsNullOrWhiteSpace($Root)) {
    Write-Host '未提供扫描目录，已取消。' -ForegroundColor Red
    exit 1
}
$Root = [System.IO.Path]::GetFullPath($Root)
if (-not (Test-Path -LiteralPath $Root -PathType Container)) {
    Write-Host "扫描目录不存在：$Root" -ForegroundColor Red
    exit 1
}

function Write-Title([string]$t) { Write-Host ''; Write-Host $t -ForegroundColor Cyan }

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Write-Host '本脚本需要管理员权限：请右键 服务管理.bat -> 以管理员身份运行，或在管理员 PowerShell 中运行本脚本。' -ForegroundColor Red; exit 1 }
if (-not (Test-Path -LiteralPath $Single)) { Write-Host "找不到 fix_push_largefiles.ps1（应与本脚本同目录）：$Single" -ForegroundColor Red; exit 1 }

# ---------------- 发现仓库 ----------------
Write-Title "扫描目录：$Root"

function Find-Repos {
    param([string]$ScanRoot)
    $map = @{}
    $scripts = @(Get-ChildItem -LiteralPath $ScanRoot -Recurse -Filter 'git_sync_realtime_*.ps1' -File -ErrorAction SilentlyContinue)
    foreach ($s in $scripts) {
        $txt = ''
        try { $txt = Get-Content -LiteralPath $s.FullName -Raw -Encoding UTF8 -ErrorAction SilentlyContinue } catch { }
        if (-not $txt) { continue }
        $rp = [regex]::Match($txt, '\$RepoPath\s*=\s*''([^'']+)''').Groups[1].Value
        if (-not $rp -or -not (Test-Path -LiteralPath (Join-Path $rp '.git'))) { continue }
        $br = [regex]::Match($txt, '\$Branch\s*=\s*''([^'']+)''').Groups[1].Value
        $rm = [regex]::Match($txt, '\$Remote\s*=\s*''([^'']+)''').Groups[1].Value
        if (-not $rm) { $rm = 'origin' }
        $leaf   = Split-Path -Path $rp -Leaf
        $prefer = $s.Name -clike "*$leaf*"
        $key    = $rp.ToLowerInvariant()
        $entry  = [pscustomobject]@{ RepoPath = $rp; Branch = $br; Remote = $rm; Script = $s.FullName; Prefer = $prefer; Time = $s.LastWriteTime }
        if (-not $map.ContainsKey($key)) { $map[$key] = $entry }
        else {
            $cur = $map[$key]
            if (($prefer -and -not $cur.Prefer) -or ($prefer -eq $cur.Prefer -and $s.LastWriteTime -gt $cur.Time)) { $map[$key] = $entry }
        }
    }
    return @($map.Values | Sort-Object -Property RepoPath)
}

function Find-Svc {
    param([string]$RepoPath)
    $leaf = Split-Path -Path $RepoPath -Leaf
    $cand = "GitAutoSync_$leaf"
    if (Get-Service -Name $cand -ErrorAction SilentlyContinue) { return $cand }
    $hit = Get-Service -Name 'GitAutoSync*' -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "*$leaf*" } | Select-Object -First 1
    if ($hit) { return $hit.Name }
    return ''
}

$repos = Find-Repos -ScanRoot $Root
if ($repos.Count -eq 0) { Write-Host '没有找到任何被同步的 Git 仓库。' -ForegroundColor Yellow; exit 0 }

Write-Host "发现 $($repos.Count) 个仓库：" -ForegroundColor Green
$i = 0
foreach ($r in $repos) {
    $i++
    $svc = Find-Svc -RepoPath $r.RepoPath
    Write-Host ("  [{0}] {1}" -f $i, $r.RepoPath)
    Write-Host ("      分支 {0} / 远程 {1} / 服务 {2}" -f $(if ($r.Branch) { $r.Branch } else { '(自动)' }), $r.Remote, $(if ($svc) { $svc } else { '未找到' }))
}

# ---------------- 询问策略（各问一次） ----------------
if ($KeepStopped) { $restartFlag = $false }
elseif ($AutoRestart) { $restartFlag = $true }
else {
    Write-Host ''
    $a = Read-Host '修复完成后是否自动重启同步服务？(Y=恢复后台自动同步 / N=保持停止，回车默认 Y)'
    $restartFlag = ($a -notmatch '^[nN]')
}

if ($AutoCleanup) { $cleanupFlag = $true }
else {
    $b = Read-Host '是否顺便清理各仓库 .git 中已废弃的大文件对象（可回收空间）？(Y/n)'
    $cleanupFlag = ($b -notmatch '^[nN]')
}

# ---------------- 逐个处理 ----------------
foreach ($r in $repos) {
    $leaf = Split-Path -Path $r.RepoPath -Leaf
    Write-Title ("========== {0} ==========" -f $r.RepoPath)
    $svc = Find-Svc -RepoPath $r.RepoPath

    $branch = $r.Branch
    if (-not $branch) { $branch = (git -C $r.RepoPath rev-parse --abbrev-ref HEAD 2>$null) }
    if (-not $branch -or $branch -eq 'HEAD') {
        Write-Host '无法确定分支，跳过' -ForegroundColor Yellow
        [void]$Summary.Add([pscustomobject]@{ 仓库 = $leaf; 结果 = '跳过（分支未知）' })
        continue
    }

    # 预检：连远程
    $fetchOk = $false
    for ($k = 1; $k -le 2; $k++) {
        git -C $r.RepoPath fetch --quiet $r.Remote $branch 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) { $fetchOk = $true; break }
        Start-Sleep -Seconds 3
    }
    if (-not $fetchOk) {
        Write-Host '无法连接远程仓库，跳过' -ForegroundColor Yellow
        [void]$Summary.Add([pscustomobject]@{ 仓库 = $leaf; 结果 = '跳过（远程连接失败）' })
        continue
    }

    $ahead = 0
    $aheadTxt = (git -C $r.RepoPath rev-list --count "$($r.Remote)/$branch..HEAD" 2>$null)
    if ($aheadTxt) { $ahead = [int]$aheadTxt }
    $dirty = @(git -C $r.RepoPath status --porcelain).Count

    if ($ahead -eq 0 -and $dirty -eq 0) {
        Write-Host '已同步，无需处理' -ForegroundColor Green
        [void]$Summary.Add([pscustomobject]@{ 仓库 = $leaf; 结果 = '已同步（无需处理）' })
        continue
    }

    Write-Host ("需要处理：未推送提交 $ahead 个，工作区改动 $dirty 个")

    $childArgs = @(
        '-NoProfile','-ExecutionPolicy','Bypass','-File',$Single,
        '-RepoPath',$r.RepoPath,'-Branch',$branch,'-Remote',$r.Remote,
        '-Cleanup', $(if ($cleanupFlag) { 'yes' } else { 'no' }),
        '-Restart', $(if ($restartFlag) { 'yes' } else { 'no' })
    )
    if ($svc) { $childArgs += @('-SvcName', $svc) }

    & powershell @childArgs 2>&1 | ForEach-Object { "    $_" }
    $code = $LASTEXITCODE
    if ($code -eq 0) {
        [void]$Summary.Add([pscustomobject]@{ 仓库 = $leaf; 结果 = '已修复并推送成功' })
    } else {
        [void]$Summary.Add([pscustomobject]@{ 仓库 = $leaf; 结果 = "失败（退出码 $code，详见 fix_push_$leaf.log）" })
    }
}

# ---------------- 汇总 ----------------
Write-Title '==================== 汇总 ===================='
$Summary | Format-Table -AutoSize
if ($restartFlag) { Write-Host '同步服务已按要求恢复运行。' -ForegroundColor Green }
else { Write-Host '同步服务保持停止。' -ForegroundColor Yellow }
Write-Host ''
Write-Host '如仍有失败项，请检查对应的 fix_push_*.log；提交 Issue 时可一并附上。'
